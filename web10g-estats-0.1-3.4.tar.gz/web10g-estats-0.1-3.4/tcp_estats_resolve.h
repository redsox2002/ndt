


int resolve_web10g_nladdr(const char *_name, int *_fmly_id_p, int *_mcast_grp_id_p);
